﻿

// Variables globales
const formateurQuestions = [];
let etudiantScore = 0;

// Afficher la section sélectionnée
function showSection(section) {
    const sections = ['formateur', 'etudiant', 'admin'];
    sections.forEach(sec => {
        document.getElementById(sec).style.display = (sec === section) ? 'block' : 'none';
    });

    if (section === 'etudiant') {
        loadQuiz(); // Charger le quiz lorsque l'étudiant se connecte
        document.getElementById('start-quiz').style.display = formateurQuestions.length > 0 ? 'block' : 'none';
    }
}

// Soumettre les questions créées par le formateur
document.getElementById('create-quiz-form').addEventListener('submit', function (event) {
    event.preventDefault();
    const questionInputs = document.querySelectorAll('input[type="text"]');
    const answerSelects = document.querySelectorAll('select');

    formateurQuestions.length = 0; // Réinitialiser les questions
    questionInputs.forEach((input, index) => {
        const questionText = input.value;
        const answer = answerSelects[index].value;
        formateurQuestions.push({ question: questionText, answer: answer });
    });

    document.getElementById('confirmation-message').style.display = 'block';
    console.log('Questions soumises:', formateurQuestions);
});

// Démarrer le QCM pour l'étudiant
document.getElementById('start-quiz').addEventListener('click', function () {
    document.getElementById('quiz-container').style.display = 'block';
    loadQuiz();
});

// Charger le quiz
function loadQuiz() {
    const quizElement = document.getElementById('quiz');
    quizElement.innerHTML = '';
    formateurQuestions.forEach((item, index) => {
        const questionElement = document.createElement('div');
        questionElement.className = 'col-md-6 mb-3'; // Ajustement de la mise en page
        questionElement.innerHTML = `
            <p>${item.question}</p>
            <select class="form-control" data-index="${index}">
                <option value="Vrai">Vrai</option>
                <option value="Faux">Faux</option>
            </select>
        `;
        quizElement.appendChild(questionElement);
    });

    document.getElementById('submit-quiz').style.display = 'block';
}

// Soumettre les réponses de l'étudiant
document.getElementById('submit-quiz').addEventListener('click', function () {
    const selectedAnswers = document.querySelectorAll('select[data-index]');
    let correctAnswers = 0;

    selectedAnswers.forEach(select => {
        const index = select.getAttribute('data-index');
        const studentAnswer = select.value;
        if (formateurQuestions[index].answer === studentAnswer) {
            correctAnswers++;
        }
    });

    etudiantScore = (correctAnswers / formateurQuestions.length) * 10;
    document.getElementById('score').style.display = 'block';
    document.getElementById('voir-note').style.display = 'block'; // Afficher "Voir Note"
    document.getElementById('submit-quiz').style.display = 'none';

    // Afficher la note sur l'espace Formateur
    document.getElementById('student-score').style.display = 'block';
    document.getElementById('score-result').innerText = etudiantScore;
});

// Bouton "Voir Note"
document.getElementById('voir-note').addEventListener('click', function () {
    alert(`Votre note est: ${etudiantScore}/10`);
});




// Admin login details

    const adminFullName = "admin";  // Nom complet (nom + prénom)
    const adminPassword = "admin";        // Mot de passe

    // Fonction pour gérer la connexion admin
    function loginAdmin() {
                const enteredFullName = document.getElementById("admin-fullname").value.toLowerCase();
    const enteredPassword = document.getElementById("admin-password").value;

    // Vérification des informations de connexion
    if (enteredFullName === adminFullName && enteredPassword === adminPassword) {
        // Masquer le formulaire de connexion
        document.getElementById("admin-login").style.display = "none";
    // Afficher le tableau de bord de gestion admin
    document.getElementById("admin-dashboard").style.display = "block";
                } else {
        alert("Nom complet ou Mot de passe incorrect. Veuillez réessayer.");
                }
            }

    // Fonction pour gérer la déconnexion admin
    function logoutAdmin() {
        // Réafficher le formulaire de connexion
        document.getElementById("admin-login").style.display = "block";

    // Masquer le tableau de bord admin
    document.getElementById("admin-dashboard").style.display = "none";

    // Réinitialiser les champs de connexion
    document.getElementById("admin-fullname").value = '';
    document.getElementById("admin-password").value = '';
            }



            ///

            
        // code pour masquer l'écran de bienvenue après 3 secondes et afficher le contenu de l'application
        setTimeout(function () {
            document.getElementById("welcome-screen").style.display = "none"; // Masquer l'écran de bienvenue
            document.getElementById("app-content").style.display = "block";   // Afficher le contenu principal
        }, 3000); // 3000 millisecondes = 3 secondes
    

        
            // Fonction pour gérer la soumission du formulaire
            document.getElementById("create-quiz-form").addEventListener("submit", function (event) {
                event.preventDefault(); // Empêche le rechargement de la page

                // Affiche le message de confirmation
                document.getElementById("confirmation-message").style.display = "block";

                // Optionnel : Réinitialiser le formulaire après soumission
                document.getElementById("create-quiz-form").reset();
            });



















































/*
// Exemple de tableau pour stocker les notes des étudiants
let studentScores = [];

// Fonction pour gérer la soumission du quiz (à intégrer dans le quiz étudiant)
function submitQuiz(studentName, score) {
    // Enregistrer la note de l'étudiant
    studentScores.push({ name: studentName, score: score });
    alert(`Merci, ${studentName}! Votre note est ${score}.`);
}

// Fonction pour afficher les notes des étudiants dans le tableau de bord Admin
function displayStudentScores() {
    const scoresTableBody = document.getElementById("scores-table-body");
    scoresTableBody.innerHTML = ''; // Réinitialiser le tableau

    studentScores.forEach(student => {
        const row = document.createElement("tr");
        row.innerHTML = `<td>${student.name}</td><td>${student.score}</td>`;
        scoresTableBody.appendChild(row);
    });
}

// Exemple de fonction pour gérer le quiz étudiant
function startQuiz() {
    // Exemple de score généré après le quiz
    const exampleScore = 8; // À remplacer par le score réel obtenu par l'étudiant
    const studentName = "Étudiant 1"; // À remplacer par le nom de l'étudiant

    // Soumettre le quiz (enregistrer le score)
    submitQuiz(studentName, exampleScore);

    // Afficher les résultats sur l'admin après la connexion
    if (document.getElementById("admin-dashboard").style.display === "block") {
        displayStudentScores();
    }
}

// Admin login details (Nom, Mot de passe prédéfinis pour cet exemple)
const adminNom = "admin";
const adminPassword = "admin";

// Fonction pour gérer la connexion admin
function loginAdmin() {
    const enteredFullName = document.getElementById("admin-fullname").value.split(' ');
    const enteredNom = enteredFullName[0]; // On suppose que le nom est le premier mot
    const enteredPassword = document.getElementById("admin-password").value;

    // Vérification des informations de connexion
    if (enteredNom === adminNom && enteredPassword === adminPassword) {
        // Masquer le formulaire de connexion
        document.getElementById("admin-login").style.display = "none";
        // Afficher le tableau de bord de gestion
        document.getElementById("admin-dashboard").style.display = "block";

        // Remplir le tableau des notes
        displayStudentScores();
    } else {
        alert("Nom ou Mot de passe incorrect. Veuillez réessayer.");
    }
}

// Fonction pour gérer la déconnexion admin
function logoutAdmin() {
    // Afficher à nouveau le formulaire de connexion
    document.getElementById("admin-login").style.display = "block";
    document.getElementById("admin-dashboard").style.display = "none"; // Masquer le tableau de bord

    // Réinitialiser les champs de connexion
    document.getElementById("admin-fullname").value = '';
    document.getElementById("admin-password").value = '';
}

*/






// Exemple de fonction pour gérer le quiz étudiant
function finishQuiz() {
    const studentName = "Étudiant 1"; // Remplacez cela par le nom réel de l'étudiant
    const score = calculateScore(); // Remplacez par votre logique de calcul de score

    // Soumettre le quiz (enregistrer le score)
    submitQuiz(studentName, score);

    // Afficher les résultats sur l'admin après la connexion
    if (document.getElementById("admin-dashboard").style.display === "block") {
        displayStudentScores();
    }
}
